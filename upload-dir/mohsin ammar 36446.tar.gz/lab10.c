
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>
#define BUF_SIZE 100

int main(int argc, char* argv[]) {

int input_fd; /* Input file descriptors */
ssize_t ret_in; /* Number of bytes returned by read() */
char buffer[BUF_SIZE]; /* Character buffer */

/* Are src and dest file name arguments missing */
if(argc != 3){
printf ("Usage: lab10 file string");
return 1;
}

/* Create input file descriptor */
input_fd = open (argv [1], O_RDONLY);
if (input_fd == -1) {
perror ("open");
return 2;
}

/* Copy process */
while((ret_in = read (input_fd, &buffer, BUF_SIZE)) > 0){
if(strstr(buffer,argv[2]) != NULL){
printf("String found in file %s\n Line: %s",argv[1],buffer);
}
}

/* Close file descriptors */
close (input_fd);

return (EXIT_SUCCESS);
}
